//
//  TapViewController.swift
//  GesturesDemo_Swift
//
//  Created by Prathyusha kotagiri on 10/25/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

import UIKit

class TapViewController: UIViewController {

    @IBOutlet weak var testView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let singleTapGestureRecognizer:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action:"handleSingleTapGesture:")
        self.testView.addGestureRecognizer(singleTapGestureRecognizer);
        
        let doubleTapGestureRecognizer:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action:"handleDoubleTapGesture:")
        doubleTapGestureRecognizer.numberOfTapsRequired = 2;
        doubleTapGestureRecognizer.numberOfTouchesRequired = 2;
        self.testView.addGestureRecognizer(doubleTapGestureRecognizer);
    }
    
    //MARK: Single Tap
    func handleSingleTapGesture(sender:UITapGestureRecognizer){
       
        var newWidth:CGFloat = 100.0;
        
        if (self.testView.frame.size.width == 100.0) {
            newWidth = 200.0;
        }
        
        let currentCenter:CGPoint = self.testView.center;
        
        self.testView.frame = CGRectMake(self.testView.frame.origin.x, self.testView.frame.origin.y, newWidth, self.testView.frame.size.height);
        self.testView.center = currentCenter;
    }
    
    //MARK: Double Tap
    func handleDoubleTapGesture(sender:UITapGestureRecognizer){
        
        var newSize:CGSize = CGSizeMake(100.0, 100.0);
        
        if (self.testView.frame.size.width == 100.0) {
            newSize.width = 200.0;
            newSize.height = 200.0;
        }
        
        let currentCenter:CGPoint = self.testView.center;
        
        self.testView.frame = CGRectMake(self.testView.frame.origin.x, self.testView.frame.origin.y, newSize.width, newSize.height);
        self.testView.center = currentCenter;

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
