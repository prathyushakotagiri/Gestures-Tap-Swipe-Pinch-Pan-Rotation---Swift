//
//  RotationViewController.swift
//  GesturesDemo_Swift
//
//  Created by Prathyusha kotagiri on 10/25/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

import UIKit

class RotationViewController: UIViewController {

    @IBOutlet weak var testView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let rotationGestureRecognizer:UIRotationGestureRecognizer = UIRotationGestureRecognizer(target: self, action: "handleRotationWithGestureRecognizer:")
        self.testView.addGestureRecognizer(rotationGestureRecognizer)
    }

    //MARK: Rotation Gesture Method
    func handleRotationWithGestureRecognizer(rotationGestureRecognizer:UIRotationGestureRecognizer){
        
        self.testView.transform = CGAffineTransformRotate(self.testView.transform, rotationGestureRecognizer.rotation);
        
        //Making the rotation value to zero
        rotationGestureRecognizer.rotation = 0.0;
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
