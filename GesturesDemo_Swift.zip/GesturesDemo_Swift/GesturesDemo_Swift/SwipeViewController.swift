//
//  SwipeViewController.swift
//  GesturesDemo_Swift
//
//  Created by Prathyusha kotagiri on 10/25/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

import UIKit

class SwipeViewController: UIViewController {

    var viewBlack: UIView?
    var viewGreen: UIView?
    var viewOrange: UIView?
    
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
    
        print("Orange:\(self.viewOrange!.frame)")
        print("Black:\(self.viewBlack!.frame)")
        print("Green:\(self.viewGreen!.frame)")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.viewOrange = UIView(frame:CGRectMake(0, self.view.center.y-50.0, self.view.frame.size.width, 100))
        self.viewOrange!.backgroundColor = UIColor.orangeColor()
        self.view.addSubview(self.viewOrange!)
        
        self.viewBlack = UIView(frame:CGRectMake(self.view.frame.size.width, self.view.center.y-50.0, self.view.frame.size.width, 100.0))
        self.viewBlack!.backgroundColor = UIColor.blackColor()
        self.view.addSubview(self.viewBlack!)
        

        self.viewGreen = UIView(frame:CGRectMake(-self.view.frame.size.width, self.view.center.y-50.0, self.view.frame.size.width, 100.0)) as UIView
        self.viewGreen!.backgroundColor = UIColor.greenColor()
        self.view.addSubview(self.viewGreen!)
        
        
        //Right and Left swipes for orange View
        let swipeRightOrange:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: "slideToRightWithGestureRecognizer:")
        swipeRightOrange.direction = UISwipeGestureRecognizerDirection.Right
        
         let swipeLeftOrange:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: "slideToLeftWithGestureRecognizer:")
        swipeLeftOrange.direction = UISwipeGestureRecognizerDirection.Left
        
        //Right swipe for Black View
       let swipeRightBlack:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: "slideToRightWithGestureRecognizer:")
        swipeRightBlack.direction = UISwipeGestureRecognizerDirection.Right;
        
        //Left swipe for Green View
       let swipeLeftGreen:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: "slideToLeftWithGestureRecognizer:")
        swipeLeftGreen.direction = UISwipeGestureRecognizerDirection.Left;
        
        self.viewOrange!.addGestureRecognizer(swipeRightOrange)
        self.viewOrange!.addGestureRecognizer(swipeLeftOrange)
        self.viewBlack!.addGestureRecognizer(swipeRightBlack)
        self.viewGreen!.addGestureRecognizer(swipeLeftGreen)
    }
    
    //MARK: Right Swipe
    func slideToRightWithGestureRecognizer(sender:UISwipeGestureRecognizer){
        
        UIView.animateWithDuration(0.5, animations: { () -> Void in
            
            self.viewOrange!.frame = CGRectOffset(self.viewOrange!.frame, self.view.frame.size.width, 0.0)
            self.viewBlack!.frame = CGRectOffset(self.viewBlack!.frame, self.view.frame.size.width, 0.0)
            self.viewGreen!.frame = CGRectOffset(self.viewGreen!.frame, self.view.frame.size.width, 0.0)
            
        }, completion: nil)
    }
    
    //MARK: Left Swipe
    func slideToLeftWithGestureRecognizer(sender:UISwipeGestureRecognizer){
        
        UIView.animateWithDuration(0.5, animations: { () -> Void in
            
            self.viewOrange!.frame = CGRectOffset(self.viewOrange!.frame, -self.view.frame.size.width, 0.0)
            self.viewBlack!.frame = CGRectOffset(self.viewBlack!.frame, -self.view.frame.size.width, 0.0)
            self.viewGreen!.frame = CGRectOffset(self.viewGreen!.frame, -self.view.frame.size.width, 0.0)
            
            }, completion: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
