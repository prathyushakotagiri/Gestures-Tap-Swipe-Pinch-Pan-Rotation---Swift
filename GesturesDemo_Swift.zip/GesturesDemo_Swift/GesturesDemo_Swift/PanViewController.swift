//
//  PanViewController.swift
//  GesturesDemo_Swift
//
//  Created by Prathyusha kotagiri on 10/25/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

import UIKit

class PanViewController: UIViewController {

    @IBOutlet weak var testView: UIImageView!
    
    override func viewDidLoad() {
       
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let panGestureRecognizer:UIPanGestureRecognizer = UIPanGestureRecognizer(target: self, action: "moveViewWithGestureRecognizer:")
        self.testView.addGestureRecognizer(panGestureRecognizer)
    }
    
    //MARK: Pan Gesture Method
    func moveViewWithGestureRecognizer(panRecognizer:UIPanGestureRecognizer){
        
        let translation:CGPoint = panRecognizer.translationInView(self.view)
        
        var imageViewPosition: CGPoint = self.testView.center;
        imageViewPosition.x += translation.x;
        imageViewPosition.y += translation.y;
        self.testView.center = imageViewPosition;
       
        panRecognizer.setTranslation(CGPointZero, inView: self.view)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
